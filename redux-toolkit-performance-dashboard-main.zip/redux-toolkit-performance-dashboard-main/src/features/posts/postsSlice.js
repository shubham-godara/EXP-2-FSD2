import { createSlice } from "@reduxjs/toolkit";

const initialState = {
        posts: [],
};

const postsSlice = createSlice({
        name: "posts",
        initialState,

        reducers: {
                // CREATE
                addPost: (state, action) => {
                        state.posts.push(action.payload);
                },

                // UPDATE
                updatePost: (state, action) => {
                        const { id, title, platform } = action.payload;

                        const post = state.posts.find((post) => post.id === id);

                        if (post) {
                                post.title = title;
                                post.platform = platform;
                        }
                },

                // DELETE
                deletePost: (state, action) => {
                        state.posts = state.posts.filter(
                                (post) => post.id !== action.payload
                        );
                },
        },
});

export const {
        addPost,
        updatePost,
        deletePost,
} = postsSlice.actions;

export default postsSlice.reducer;