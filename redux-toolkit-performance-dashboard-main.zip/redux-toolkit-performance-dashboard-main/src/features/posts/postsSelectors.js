import { createSelector } from "@reduxjs/toolkit";

const selectPosts = (state) => state.posts.posts;

export const selectPostCount = createSelector(
        [selectPosts],
        (posts) => posts.length
);

export const selectInstagramPosts = createSelector(
        [selectPosts],
        (posts) =>
                posts.filter((post) => post.platform === "Instagram")
);

export const selectFacebookPosts = createSelector(
        [selectPosts],
        (posts) =>
                posts.filter((post) => post.platform === "Facebook")
);
