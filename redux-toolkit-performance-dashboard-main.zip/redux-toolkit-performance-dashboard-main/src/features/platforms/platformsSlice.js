import { createSlice } from "@reduxjs/toolkit";

const initialState = {
        platforms: [],
};

const platformsSlice = createSlice({
        name: "platforms",
        initialState,

        reducers: {
                // CREATE
                addPlatform: (state, action) => {
                        state.platforms.push(action.payload);
                },

                // UPDATE
                updatePlatform: (state, action) => {
                        const { id, name } = action.payload;

                        const platform = state.platforms.find(
                                (platform) => platform.id === id
                        );

                        if (platform) {
                                platform.name = name;
                        }
                },

                // DELETE
                deletePlatform: (state, action) => {
                        state.platforms = state.platforms.filter(
                                (platform) => platform.id !== action.payload
                        );
                },
        },
});

export const {
        addPlatform,
        updatePlatform,
        deletePlatform,
} = platformsSlice.actions;

export default platformsSlice.reducer;