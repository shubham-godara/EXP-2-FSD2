import { createSelector } from "@reduxjs/toolkit";

const selectPlatforms = (state) => state.platforms.platforms;

export const selectPlatformCount = createSelector(
        [selectPlatforms],
        (platforms) => platforms.length
);

export const selectInstagramPlatforms = createSelector(
        [selectPlatforms],
        (platforms) =>
                platforms.filter((platform) => platform.name === "Instagram")
);