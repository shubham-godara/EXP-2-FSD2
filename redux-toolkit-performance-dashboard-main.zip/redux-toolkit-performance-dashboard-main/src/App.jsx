import { useSelector, useDispatch } from "react-redux";
import { useMemo, useCallback, memo } from "react";

import {
  addPost,
  updatePost,
  deletePost,
} from "./features/posts/postsSlice";

import {
  addPlatform,
  updatePlatform,
  deletePlatform,
} from "./features/platforms/platformsSlice";

import {
  selectPostCount,
  selectInstagramPosts,
  selectFacebookPosts,
} from "./features/posts/postsSelectors";

import {
  selectPlatformCount,
  selectInstagramPlatforms,
} from "./features/platforms/platformsSelectors";

import "./App.css";

const PostItem = memo(({ post, onUpdate, onDelete }) => {
  console.log("Post rendered:", post.title);

  return (
    <div className="card">
      <h3>{post.title}</h3>
      <p>Platform: {post.platform}</p>

      <button onClick={() => onUpdate(post.id)}>
        Update Post
      </button>

      <button className="delete" onClick={() => onDelete(post.id)}>
        Delete Post
      </button>
    </div>
  );
});

const PlatformItem = memo(({ platform, onUpdate, onDelete }) => {
  console.log("Platform rendered:", platform.name);

  return (
    <div className="card">
      <h3>{platform.name}</h3>

      <button onClick={() => onUpdate(platform.id)}>
        Update Platform
      </button>

      <button className="delete" onClick={() => onDelete(platform.id)}>
        Delete Platform
      </button>
    </div>
  );
});

function App() {
  const dispatch = useDispatch();

  const posts = useSelector((state) => state.posts.posts);
  const platforms = useSelector((state) => state.platforms.platforms);

  const postCount = useSelector(selectPostCount);
  const instagramPosts = useSelector(selectInstagramPosts);
  const facebookPosts = useSelector(selectFacebookPosts);

  const platformCount = useSelector(selectPlatformCount);
  const instagramPlatforms = useSelector(selectInstagramPlatforms);

  const postSummary = useMemo(
    () => ({
      total: postCount,
      instagram: instagramPosts.length,
      facebook: facebookPosts.length,
    }),
    [postCount, instagramPosts, facebookPosts]
  );

  const handleAddPost = () => {
    dispatch(
      addPost({
        id: Date.now(),
        title: "New Optimized Post",
        platform: "Instagram",
      })
    );
  };

  const handleUpdatePost = (id) => {
    dispatch(
      updatePost({
        id,
        title: "Updated Post",
        platform: "Facebook",
      })
    );
  };

  const handleDeletePost = (id) => {
    dispatch(deletePost(id));
  };

  const handleAddPlatform = () => {
    dispatch(
      addPlatform({
        id: Date.now(),
        name: "Instagram",
      })
    );
  };

  const handleUpdatePlatform = (id) => {
    dispatch(
      updatePlatform({
        id,
        name: "Facebook",
      })
    );
  };

  const handleDeletePlatform = (id) => {
    dispatch(deletePlatform(id));
  };

  return (
    <div className="app">
      <h1>Redux Toolkit Experiment 1.2.2</h1>

      <section>
        <h2>Performance Dashboard</h2>

        <div className="stats">
          <div>Total Posts: {postSummary.total}</div>
          <div>Instagram Posts: {postSummary.instagram}</div>
          <div>Facebook Posts: {postSummary.facebook}</div>
          <div>Total Platforms: {platformCount}</div>
          <div>Instagram Platforms: {instagramPlatforms.length}</div>
        </div>
      </section>

      <section>
        <h2>Posts</h2>

        <button onClick={handleAddPost}>Add Post</button>

        {posts.map((post) => (
          <PostItem
            key={post.id}
            post={post}
            onUpdate={handleUpdatePost}
            onDelete={handleDeletePost}
          />
        ))}
      </section>

      <section>
        <h2>Platforms</h2>

        <button onClick={handleAddPlatform}>Add Platform</button>

        {platforms.map((platform) => (
          <PlatformItem
            key={platform.id}
            platform={platform}
            onUpdate={handleUpdatePlatform}
            onDelete={handleDeletePlatform}
          />
        ))}
      </section>
    </div>
  );
}

export default App;